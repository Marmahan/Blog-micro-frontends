import React from "react";
import { TransitionGroup, CSSTransition } from "react-transition-group";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import Login from './login';

class Home extends React.Component{
  state={
    email: JSON.parse(localStorage.getItem('allProjects')) || [],
    islogged:''
  }


  setemail =(v)=>{
    this.setState({
      email: this.state.email.concat(v)
    },() => {
      localStorage.setItem('email', JSON.stringify(this.state.email))
    });
  }

  render(){
    return(
      this.state.email ? (
        <div>
          <h1>Logged in success</h1>
        </div>
      ):
      ( 
        <div className="container">
          <div className="row">
            <div className="col s4">
              <Login setemail={this.setemail}/> {/*this will change the state from inside the login*/}
            </div>
            <div className="col s8">
              Body
            </div>
          </div>
        </div>
      )

    )
  }
}

export default Home;